# THIS FILE IS GENERATED FROM KIVYMD SETUP.PY
__version__ = "0.104.2"
__hash__ = "bc7d1f5a2385dceaaff30ec004e54a7011ca0671"
__short_hash__ = "bc7d1f5"
__date__ = "2021-06-06"
