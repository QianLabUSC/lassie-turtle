/*
 * @Author: Ryoma Liu -- ROBOLAND
 * @Date: 2021-11-27 16:20:05
 * @Last Modified by: Ryoma Liu
 * @Last Modified time: 2022-02-02 19:12:01
 */

#include "main.h"
#include "rclcpp/rclcpp.hpp"

/**
 * main - entrance of turtle robot Scontroller.
 * @param argc
 * @param argv
 * @return 0
 */

int main(int argc, char **argv)
{
	rclcpp::init(argc, argv); // initial ros
	// receive information from high level sensor
	std::shared_ptr<upperproxy> Upper_proxy_ = std::make_shared<upperproxy>();
	// change controller
	ControllerMonitor &monitor = ControllerMonitor::GetStateMonitor();

	// detect motor status, and publish motion command
	std::shared_ptr<lowerproxy> Lower_proxy_ = std::make_shared<lowerproxy>();

	// Upper_proxy_.Init();
	monitor.Init(); // initial monitor

	rclcpp::Rate loop_rate(100); // renew frequence 100HZ
	while (rclcpp::ok())
	{
		rclcpp::spin_some(Upper_proxy_);
    		rclcpp::spin_some(Lower_proxy_);
		// update leg feedback status
		Lower_proxy_->UpdateJoystickStatus(turtle_);
		Upper_proxy_->UpdateGuiCommand(turtle_);             //update gui command
		// generate control command
		monitor.ControlCommand(turtle_);
		// publish control command
		Lower_proxy_->PublishControlCommand(turtle_);
    		Upper_proxy_->PublishStatusFeedback(turtle_);             //publish current times
		loop_rate.sleep();
	}

	return 0;
}
