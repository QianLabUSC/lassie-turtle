/*
 * @Author: Ryoma Liu -- ROBOLAND 
 * @Date: 2021-11-21 21:58:00 
 * @Last Modified by: Ryoma Liu
 * @Last Modified time: 2022-02-02 18:31:48
 */

#include "proxy/lowerproxy.h"
#include <fstream>
#include <iostream>
#include <iomanip>

/**
 * lowerproxy - class to publish control command to webots turtle_namespace or real 
 * agile taur.
 */
const double PI = 3.141592653589793238463;
const double TWO_PI = PI*2;
namespace turtle_namespace{
namespace control{


lowerproxy::lowerproxy(std::string name) : Node(name){
    std::cout<<"Start to create the ros node subscriber and publisher"
                <<std::endl;
    // create a list of low level position command publisher 
    joint0_publisher = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/joint0_position_controller/commands", 10);
    joint1_publisher = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/joint1_position_controller/commands", 10);
    // replace previous servo topics with current direct drive topic
    servo0_publisher_dd = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/servo0_controller/commands", 10);
    servo1_publisher_dd = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/servo1_controller/commands", 10);

    servo0_publisher = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/traveler_servo_big_1", 10);
    servo1_publisher = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/traveler_servo_big_2", 10);
    servo2_publisher = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/traveler_servo_small_1", 10);
    servo3_publisher = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/traveler_servo_small_2", 10);
    controller_state_publisher = this->create_publisher<std_msgs::msg::Float64MultiArray>
        ("/controller", 10);
    // Robot_state_publisher = this->create_publisher<travelermsgs::msg::RobotState>
    //     ("/robot_state", 10);
    Leg1_subscriber = this->create_subscription
                        <control_msgs::msg::DynamicJointState>
        ("/dynamic_joint_states", 10, std::bind(&lowerproxy::handle_joint_state, this, _1));


    _count = 0;

    // RCLCPP_INFO(this->get_logger(), "Publisher created!!");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
}

float lowerproxy::fmodf_mpi_pi(float f)
{
  if (f>0)
    return (fmodf(f+PI, TWO_PI) - PI);
  else
    return (fmodf(f-PI, TWO_PI) + PI);
}

void lowerproxy::getToeForce(){
    float u0 = turtle_inter_.turtle_chassis.left_limb_motor.effort;
    float u1 = turtle_inter_.turtle_chassis.left_limb_motor.effort;
    float meanAng = 0;
    float diffAng = 0;
    float mot_pos0 = turtle_inter_.turtle_chassis.left_limb_motor.position + 1.79;
    float mot_pos1 = turtle_inter_.turtle_chassis.right_limb_motor.position + 1.79;
    float r = mot_pos0 - mot_pos1;
    diffAng = 0.5 * r;
    meanAng = fmodf(mot_pos1 + diffAng, PI);
    if (meanAng < 0.0) {
        meanAng += PI;
        diffAng = fmodf_mpi_pi(diffAng + PI);
    }
    float l1 =0.1;
    float l2 =0.2;
    float l1proj = l1*sin(meanAng);
    float dummy = -2/(-2*l1proj + l1*l1*sin(mot_pos0 + 
                                mot_pos1)/sqrtf(l2*l2 - l1proj*l1proj));
    turtle_inter_.turtle_chassis.left_limb_motor.toeforce = dummy * (u0+u1);
    turtle_inter_.turtle_chassis.left_limb_motor.toeforce = u0-u1;
}




void lowerproxy::handle_joint_state
    (const control_msgs::msg::DynamicJointState::SharedPtr msg){
    turtle_inter_.turtle_chassis.left_limb_motor.effort = 
                                            msg->interface_values[0].values[0];

    turtle_inter_.turtle_chassis.left_limb_motor.position = 
                                            msg->interface_values[0].values[1];

    turtle_inter_.turtle_chassis.right_limb_motor.effort = 
                                            msg->interface_values[1].values[0];
    turtle_inter_.turtle_chassis.right_limb_motor.position = 
                                            msg->interface_values[1].values[1];
   
    // getToeForce();   
}

void lowerproxy::PublishControlCommand(turtle& turtle_){

    auto message1 = std_msgs::msg::Float64MultiArray();
    auto message2 = std_msgs::msg::Float64MultiArray();
    auto message3 = std_msgs::msg::Float64MultiArray();
    auto message4 = std_msgs::msg::Float64MultiArray();
    auto message5 = std_msgs::msg::Float64MultiArray();
    auto message6 = std_msgs::msg::Float64MultiArray();

    message1.data.push_back(turtle_.turtle_control.left_limb_motor.motor_control_position);
    message2.data.push_back(turtle_.turtle_control.right_limb_motor.motor_control_position);
    message3.data.push_back(turtle_.turtle_control.left_big_servo_command);
    message4.data.push_back(turtle_.turtle_control.left_small_servo_command);
    message5.data.push_back(turtle_.turtle_control.right_big_servo_command);
    message6.data.push_back(turtle_.turtle_control.right_small_servo_command);
    // for direct drive version
    joint0_publisher->publish(message1);
    joint1_publisher->publish(message2);
    servo0_publisher_dd->publish(message3);
    servo1_publisher_dd->publish(message5);

    // for servo version
    servo0_publisher->publish(message3);
    servo1_publisher->publish(message5);
    servo2_publisher->publish(message4);
    servo3_publisher->publish(message6);

    
    // RCLCPP_INFO(this->get_logger(), "Publishing: '%f'", message.data.at(0));
    // auto message4 = travelermsgs::msg::RobotState();
    // message4.toeforce_hori = traveler_.traveler_chassis.Leg_lf.axis0.toeforce;
    // message4.toeforce_vertical = traveler_.traveler_chassis.Leg_lf.axis0.toeforce;

    // controller_state_publisher->publish(message3);
    // Robot_state_publisher->publish(message4);
}




void lowerproxy::Estop(){

}

void lowerproxy::UpdateJoystickStatus(turtle& turtle_){
    turtle_.turtle_control = turtle_inter_.turtle_control;
    turtle_.turtle_gui = turtle_inter_.turtle_gui;

    
    
}
    
} //namespace control
} //namespace turtle_namespace



