/*
 * @Author: Ryoma Liu -- ROBOLAND 
 * @Date: 2022-02-02 16:17:20 
 * @Last Modified by: Ryoma Liu
 * @Last Modified time: 2022-02-02 18:58:03
 */

#ifndef DATA_H_
#define DATA_H_
#include <stdio.h>
#include <stdlib.h>
#include <vector>

struct motor_status{
    float error;
    float effort;
    float temperature;
    float position;
    float velocity;
    float toeforce;
    float toespeed;
};


struct turtle_status
{
    motor_status left_limb_motor;
    motor_status right_limb_motor;
    float left_big_servo_pos;
    float right_big_servo_pos;
    float left_small_servo_pos;
    float right_small_servo_pos;
    
};


struct motor_command{
    uint8_t motor_control_type;
    float motor_control_effort;
    float motor_control_velocity;
    float motor_control_position;
};

struct trutle_command{
    motor_command left_limb_motor;
    motor_command right_limb_motor;
    float left_big_servo_command;
    float right_big_servo_command;
    float left_small_servo_command;
    float right_small_servo_command;
};

struct human_interface{
    float drag_traj = 0;

    // Trajectory Start Flag (run state = true or false)
    int start_flag = 0;
    bool status_update_flag = false;
};
// struct that defines the behavior of trajectories
struct TrajectoryData
{
    // Extrustion Trajectory Parameters
    float lateral_angle_range;      // arc             
    float drag_speed;               //m/s     
    float wiggle_time;                  //s

    float servo_time;        //s
    float extraction_height;    //m     
    float wiggle_frequency;        //hz  
    float insertion_angle;             //arc        
    float wiggle_amptitude;                 //arc     
};

struct turtle{
    turtle_status turtle_chassis;
    trutle_command turtle_control;
    human_interface turtle_gui;
    TrajectoryData traj_data;
};

#endif